<a href="{{ route('party.index') }}">Jeux</a>
<a href="{{ route('collection.index') }}">Collection</a>